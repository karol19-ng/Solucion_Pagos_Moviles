﻿module ICoreService

